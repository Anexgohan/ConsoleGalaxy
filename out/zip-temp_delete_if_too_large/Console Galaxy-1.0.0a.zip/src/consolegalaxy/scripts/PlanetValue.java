package consolegalaxy.scripts;

public enum PlanetValue {
    EXCELLENT,
    GREAT,
    GOOD,
    MEDIUM,
    BAD,
    SHIT,
    HELL
}
